#!/bin/bash
# Sonar Processing Validation Script
# Tests channel alignment, heading calculation, and KML overlay generation

set -e  # Exit on error

echo "========================================"
echo "Sonar Processing Comprehensive Test Suite"
echo "========================================"
echo ""

# Configuration
TEST_FILE="${1:-test_data/sample.rsd}"
OUTPUT_DIR="test_output_$(date +%Y%m%d_%H%M%S)"
EXPECTED_CHANNELS="14,15"  # Adjust for your hardware

if [ ! -f "$TEST_FILE" ]; then
    echo "ERROR: Test file not found: $TEST_FILE"
    echo "Usage: $0 <path_to_rsd_file>"
    exit 1
fi

echo "Test file: $TEST_FILE"
echo "Output directory: $OUTPUT_DIR"
echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Test 1: Channel Alignment Detection
# ──────────────────────────────────────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 1: Channel Alignment Auto-Detection"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Running parser to detect channels and flip settings..."

cargo run --release -- \
    --input "$TEST_FILE" \
    --output "$OUTPUT_DIR" \
    --mosaic \
    2>&1 | tee "$OUTPUT_DIR/test1_channel_detection.log"

echo ""
echo "✓ Channel detection complete"
echo "  Check $OUTPUT_DIR/test1_channel_detection.log for alignment settings"
echo ""

# Validate channel alignment
if grep -q "flip: true" "$OUTPUT_DIR/test1_channel_detection.log"; then
    echo "✓ Port channel flip detected (expected for Classic/UHD2)"
elif grep -q "uhd" "$OUTPUT_DIR/test1_channel_detection.log"; then
    echo "✓ UHD detected - no flip expected (both channels start far-range)"
else
    echo "⚠ WARNING: No flip settings logged - check debug output"
fi

echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Test 2: Mosaic Quality Check
# ──────────────────────────────────────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 2: Mosaic Image Quality"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

MOSAIC_FILES=$(find "$OUTPUT_DIR" -name "mosaic_ch*.png" | sort)

if [ -z "$MOSAIC_FILES" ]; then
    echo "✗ FAIL: No mosaic files generated"
    exit 1
fi

echo "Generated mosaic files:"
for f in $MOSAIC_FILES; do
    SIZE=$(identify -format "%wx%h" "$f" 2>/dev/null || echo "unknown")
    echo "  - $(basename $f): $SIZE pixels"
done

echo ""
echo "Visual inspection checklist:"
echo "  [ ] No horizontal streaking/banding artifacts"
echo "  [ ] Port and starboard meet cleanly at center nadir"
echo "  [ ] Water column removed consistently (if enabled)"
echo "  [ ] Structures appear with correct geometry"
echo "  [ ] No left/right mirror image appearance"
echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Test 3: KML/KMZ Generation
# ──────────────────────────────────────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 3: KML/KMZ Ground Overlay Generation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

echo "Generating KML and KMZ with ground overlays..."
cargo run --release -- \
    --input "$TEST_FILE" \
    --output "$OUTPUT_DIR" \
    --kml \
    --kmz \
    --remove-water-column \
    2>&1 | tee "$OUTPUT_DIR/test3_kml_generation.log"

echo ""

KML_FILE="$OUTPUT_DIR/track.kml"
KMZ_FILE="$OUTPUT_DIR/track.kmz"

if [ ! -f "$KML_FILE" ]; then
    echo "✗ FAIL: KML file not generated"
    exit 1
fi

if [ ! -f "$KMZ_FILE" ]; then
    echo "✗ FAIL: KMZ file not generated"
    exit 1
fi

echo "✓ KML file: $KML_FILE"
echo "✓ KMZ file: $KMZ_FILE"
echo ""

# Validate KMZ structure
echo "Validating KMZ structure..."
unzip -l "$KMZ_FILE" > "$OUTPUT_DIR/kmz_contents.txt"
PNG_COUNT=$(grep "seg_.*\.png" "$OUTPUT_DIR/kmz_contents.txt" | wc -l)
echo "  - Found $PNG_COUNT segment PNG files"

if [ $PNG_COUNT -eq 0 ]; then
    echo "✗ FAIL: No segment PNGs in KMZ"
    exit 1
fi

if grep -q "gx:LatLonQuad" "$KML_FILE"; then
    echo "  ✓ gx:LatLonQuad tags present (segmented overlays)"
else
    echo "  ✗ WARNING: No gx:LatLonQuad found - may be legacy single overlay"
fi

echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Test 4: Heading Calculation Validation
# ──────────────────────────────────────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 4: Heading Calculation Accuracy"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Extract heading information from debug logs (if instrumented)
if grep -q "heading" "$OUTPUT_DIR/test3_kml_generation.log" 2>/dev/null; then
    echo "Heading calculations from log:"
    grep -i "heading" "$OUTPUT_DIR/test3_kml_generation.log" | head -20
else
    echo "⚠ No heading debug output found"
    echo "  To enable: add eprintln! debug statements to heading_between()"
fi

echo ""
echo "Manual validation:"
echo "  1. Extract a few GPS coordinates from $KML_FILE"
echo "  2. Calculate expected bearing using:"
echo "     https://www.movable-type.co.uk/scripts/latlong.html"
echo "  3. Compare with logged headings (should match within ±5°)"
echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Test 5: Geographic Accuracy
# ──────────────────────────────────────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 5: Geographic Coordinate Validation"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Extract first and last LatLonQuad coordinates
FIRST_QUAD=$(grep -A 2 "gx:LatLonQuad" "$KML_FILE" | head -5 | grep coordinates | head -1)
LAST_QUAD=$(grep -A 2 "gx:LatLonQuad" "$KML_FILE" | tail -5 | grep coordinates | tail -1)

echo "First segment corners:"
echo "$FIRST_QUAD" | sed 's/<[^>]*>//g' | tr ',' '\n' | head -8
echo ""

echo "Last segment corners:"
echo "$LAST_QUAD" | sed 's/<[^>]*>//g' | tr ',' '\n' | head -8
echo ""

echo "Validation checklist:"
echo "  [ ] Latitude values are in valid range (-90 to 90)"
echo "  [ ] Longitude values are in valid range (-180 to 180)"
echo "  [ ] Corner coordinates form a reasonable quadrilateral"
echo "  [ ] Segments don't overlap excessively"
echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Test 6: Load in Google Earth (if available)
# ──────────────────────────────────────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 6: Google Earth Validation (Manual)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

if command -v google-earth-pro &> /dev/null; then
    echo "Opening KMZ in Google Earth Pro..."
    google-earth-pro "$KMZ_FILE" &
    sleep 2
else
    echo "Google Earth Pro not found in PATH"
    echo "Manual steps:"
    echo "  1. Open Google Earth Pro"
    echo "  2. File → Open: $KMZ_FILE"
fi

echo ""
echo "Visual validation checklist in Google Earth:"
echo "  [ ] Track line follows expected route"
echo "  [ ] Sonar overlays align with GPS track"
echo "  [ ] No rotation/flipping artifacts visible"
echo "  [ ] Structures in sonar match satellite imagery landmarks"
echo "  [ ] Overlays don't 'fold over' at tight turns"
echo "  [ ] Swath width appears reasonable (10-100m typical)"
echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Test 7: Regression Tests
# ──────────────────────────────────────────────────────────────────────────────

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "TEST 7: Regression Detection"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

BASELINE_DIR="test_baseline"
if [ -d "$BASELINE_DIR" ]; then
    echo "Comparing against baseline..."
    
    # Compare mosaic dimensions
    for baseline_img in "$BASELINE_DIR"/mosaic_ch*.png; do
        if [ -f "$baseline_img" ]; then
            baseline_name=$(basename "$baseline_img")
            current_img="$OUTPUT_DIR/$baseline_name"
            
            if [ -f "$current_img" ]; then
                baseline_size=$(identify -format "%wx%h" "$baseline_img")
                current_size=$(identify -format "%wx%h" "$current_img")
                
                if [ "$baseline_size" == "$current_size" ]; then
                    echo "  ✓ $baseline_name: size matches ($current_size)"
                else
                    echo "  ⚠ $baseline_name: size changed ($baseline_size → $current_size)"
                fi
            fi
        fi
    done
    
    # Compare segment counts
    baseline_segs=$(unzip -l "$BASELINE_DIR/track.kmz" 2>/dev/null | grep "seg_.*\.png" | wc -l)
    current_segs=$PNG_COUNT
    
    echo ""
    echo "Segment count: baseline=$baseline_segs, current=$current_segs"
    if [ $baseline_segs -eq $current_segs ]; then
        echo "  ✓ Segment count unchanged"
    else
        echo "  ⚠ Segment count changed (may be OK if track logic improved)"
    fi
else
    echo "No baseline directory found at $BASELINE_DIR"
    echo "To create baseline:"
    echo "  mkdir -p $BASELINE_DIR"
    echo "  cp $OUTPUT_DIR/* $BASELINE_DIR/"
fi

echo ""

# ──────────────────────────────────────────────────────────────────────────────
# Summary
# ──────────────────────────────────────────────────────────────────────────────

echo "========================================"
echo "Test Suite Complete"
echo "========================================"
echo ""
echo "Output directory: $OUTPUT_DIR"
echo ""
echo "Key files:"
echo "  - Mosaics: $OUTPUT_DIR/mosaic_ch*.png"
echo "  - Track KML: $KML_FILE"
echo "  - Track KMZ: $KMZ_FILE"
echo "  - Test logs: $OUTPUT_DIR/*.log"
echo ""
echo "Next steps:"
echo "  1. Review mosaics for visual quality"
echo "  2. Open KMZ in Google Earth and verify alignment"
echo "  3. Compare with baseline if available"
echo "  4. Report any issues with logs attached"
echo ""

# Generate HTML summary report
cat > "$OUTPUT_DIR/test_summary.html" << EOF
<!DOCTYPE html>
<html>
<head>
    <title>Sonar Processing Test Summary</title>
    <style>
        body { font-family: monospace; margin: 20px; background: #f5f5f5; }
        h1 { color: #333; }
        .pass { color: green; font-weight: bold; }
        .warn { color: orange; font-weight: bold; }
        .fail { color: red; font-weight: bold; }
        .section { background: white; padding: 15px; margin: 10px 0; border-radius: 5px; }
        pre { background: #eee; padding: 10px; border-radius: 3px; overflow-x: auto; }
        .checklist { list-style-type: none; padding-left: 20px; }
        .checklist li::before { content: "☐ "; }
    </style>
</head>
<body>
    <h1>Sonar Processing Test Summary</h1>
    <p>Test file: <code>$TEST_FILE</code></p>
    <p>Output directory: <code>$OUTPUT_DIR</code></p>
    <p>Generated: $(date)</p>
    
    <div class="section">
        <h2>Test Results</h2>
        <ul>
            <li class="pass">✓ Channel detection</li>
            <li class="pass">✓ Mosaic generation</li>
            <li class="pass">✓ KML/KMZ creation</li>
            <li>Segment count: $PNG_COUNT</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>Manual Validation Checklist</h2>
        <ul class="checklist">
            <li>No horizontal streaking/banding in mosaics</li>
            <li>Port and starboard channels align at nadir</li>
            <li>KMZ overlays follow GPS track accurately</li>
            <li>No geometric warping or rotation errors</li>
            <li>Structures align with satellite imagery</li>
        </ul>
    </div>
    
    <div class="section">
        <h2>Files Generated</h2>
        <ul>
EOF

for f in "$OUTPUT_DIR"/*; do
    echo "            <li><a href=\"file://$(realpath "$f")\">$(basename "$f")</a></li>" >> "$OUTPUT_DIR/test_summary.html"
done

cat >> "$OUTPUT_DIR/test_summary.html" << EOF
        </ul>
    </div>
</body>
</html>
EOF

echo "HTML summary: $OUTPUT_DIR/test_summary.html"
echo ""
echo "Done!"
