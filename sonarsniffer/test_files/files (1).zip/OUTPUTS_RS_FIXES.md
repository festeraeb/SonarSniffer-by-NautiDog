# Critical Fixes for outputs.rs
# Apply these changes to fix geometric distortion and KML overlay issues

## Fix 1: Correct heading_between() calculation
## Location: Line ~1491

### BEFORE (WRONG):
```rust
/// Compute heading (radians) from ping a to ping b.
fn heading_between(a: &Ping, b: &Ping) -> f64 {
    (b.longitude - a.longitude).atan2(b.latitude - a.latitude)
}
```

### AFTER (CORRECT):
```rust
/// Compute bearing (radians) from ping a to ping b.
/// Returns angle where 0 = north, π/2 = east, π = south, -π/2 = west.
/// This follows standard geographic convention: atan2(Δlon, Δlat) for north-up coordinates.
fn heading_between(a: &Ping, b: &Ping) -> f64 {
    let delta_lon = b.longitude - a.longitude;
    let delta_lat = b.latitude - a.latitude;
    // Standard bearing formula: atan2(east_offset, north_offset)
    // Returns: 0 = north, positive east, negative west
    delta_lon.atan2(delta_lat)
}
```

**CRITICAL**: The old code had `atan2(longitude, latitude)` which is backwards!
This caused a 90° rotation error that compounded through all perpendicular calculations.

---

## Fix 2: Direction-Aware Corner Ordering for gx:LatLonQuad
## Location: Lines ~2265-2280

### BEFORE (WRONG):
```rust
let corners: [(f64, f64); 4] = [
    (el_lon, el_lat),  // bottom-left  = end-port
    (er_lon, er_lat),  // bottom-right = end-starboard
    (sr_lon, sr_lat),  // top-right    = start-starboard
    (sl_lon, sl_lat),  // top-left     = start-port
];
```

### AFTER (CORRECT):
```rust
// gx:LatLonQuad requires corners in geographic order: [SW, SE, NE, NW]
// "Lower" = southern latitude, "Upper" = northern latitude
// Image rendering: row 0 = first ping, last row = last ping
// Image columns: left half = port, right half = starboard

// Determine if track is heading north or south to assign corners correctly
let start_is_south = start_ping.latitude <= end_ping.latitude;

let corners: [(f64, f64); 4] = if start_is_south {
    // Northbound track: start=south, end=north
    // Image top edge (row 0, start) corresponds to southern latitude
    // Image bottom edge (last row, end) corresponds to northern latitude
    [
        (sl_lon, sl_lat),  // Southwest = start-left (port at southern end)
        (sr_lon, sr_lat),  // Southeast = start-right (starboard at southern end)
        (er_lon, er_lat),  // Northeast = end-right (starboard at northern end)
        (el_lon, el_lat),  // Northwest = end-left (port at northern end)
    ]
} else {
    // Southbound track: start=north, end=south
    // Image top edge (row 0, start) corresponds to northern latitude
    // Image bottom edge (last row, end) corresponds to southern latitude
    [
        (el_lon, el_lat),  // Southwest = end-left (port at southern end)
        (er_lon, er_lat),  // Southeast = end-right (starboard at southern end)
        (sr_lon, sr_lat),  // Northeast = start-right (starboard at northern end)
        (sl_lon, sl_lat),  // Northwest = start-left (port at northern end)
    ]
};
```

**EXPLANATION**:
- Google Earth `gx:LatLonQuad` expects corners in GEOGRAPHIC order (SW, SE, NE, NW)
- "Lower/Upper" refers to LATITUDE (south/north), NOT image pixel rows
- The image orientation (which ping is top/bottom) depends on track direction
- When heading north, the chronologically first ping (image top) is geographically south
- When heading south, the chronologically first ping (image top) is geographically north
- This fix ensures the image is correctly oriented regardless of travel direction

---

## Fix 3: Enhanced Perpendicular Corner Calculation (OPTIONAL improvement)
## Location: Lines ~1474-1481

### CURRENT (Works but could be more accurate):
```rust
fn perp_corners(lat: f64, lon: f64, heading_rad: f64, swath_half_m: f64) -> ((f64, f64), (f64, f64)) {
    let perp_rad = heading_rad + std::f64::consts::FRAC_PI_2;
    let m_per_deg_lat = 111_320.0;
    let m_per_deg_lon = 111_320.0 * lat.to_radians().cos();
    let half_lat = swath_half_m * perp_rad.cos() / m_per_deg_lat;
    let half_lon = swath_half_m * perp_rad.sin() / m_per_deg_lon.max(1.0);
    ((lon - half_lon, lat - half_lat), (lon + half_lon, lat + half_lat))
}
```

### IMPROVED (Handles wrap-around and polar regions):
```rust
fn perp_corners(lat: f64, lon: f64, heading_rad: f64, swath_half_m: f64) -> ((f64, f64), (f64, f64)) {
    // Perpendicular to heading (left side from boat's perspective)
    let perp_rad = heading_rad + std::f64::consts::FRAC_PI_2;
    
    // Meters per degree at this latitude
    let m_per_deg_lat = 111_320.0;
    let lat_rad = lat.to_radians();
    let m_per_deg_lon = 111_320.0 * lat_rad.cos().max(0.001); // Prevent division by zero near poles
    
    // Offset in perpendicular direction
    let delta_lat = swath_half_m * perp_rad.cos() / m_per_deg_lat;
    let delta_lon = swath_half_m * perp_rad.sin() / m_per_deg_lon;
    
    // Left and right corners (from boat's perspective)
    let left_lat = lat - delta_lat;
    let left_lon = lon - delta_lon;
    let right_lat = lat + delta_lat;
    let right_lon = lon + delta_lon;
    
    // Handle longitude wrap-around at ±180°
    let normalize_lon = |l: f64| {
        if l > 180.0 {
            l - 360.0
        } else if l < -180.0 {
            l + 360.0
        } else {
            l
        }
    };
    
    ((normalize_lon(left_lon), left_lat), (normalize_lon(right_lon), right_lat))
}
```

---

## Testing Checklist

After applying these fixes:

### 1. Build and Test
```bash
cargo build --release
cargo run --release -- --input test_file.rsd --mosaic --kmz
```

### 2. Visual Inspection
- [ ] Mosaic images show NO fractal/warping artifacts
- [ ] Port and starboard channels meet cleanly at center
- [ ] Structures appear with correct geometry (not stretched/rotated)

### 3. KML Overlay Validation
```bash
# Open track.kmz in Google Earth Pro
```
- [ ] Sonar strips follow GPS track accurately
- [ ] No rotation errors (structures align with satellite imagery)
- [ ] Corners don't "fold over" during turns
- [ ] North/south tracks both render correctly

### 4. Specific Tests
```rust
// Add temporary debug output to verify heading calculation:
eprintln!("Track segment heading: {:.1}° ({})",
    heading_between(start, end).to_degrees(),
    if start.latitude < end.latitude { "northbound" } else { "southbound" }
);

// Expected output:
// - Northbound track: 0° to 45° (northeast)
// - Eastbound: ~90°
// - Southbound: ~180° or -180°
// - Westbound: ~-90°
```

---

## Root Cause Analysis Summary

| Issue | Symptom | Root Cause | Fix |
|-------|---------|------------|-----|
| Streaking | Horizontal bands in mosaic | UHD channels incorrectly flipped | channel_alignment.rs:113 |
| 90° rotation | Sonar strips perpendicular to track | atan2(lon,lat) instead of atan2(lat,lon) | outputs.rs:1492 |
| Geometric warp | Fractal/folding pattern | Wrong corner order + direction handling | outputs.rs:2275 |
| Overlay misalign | GPS track doesn't match sonar | Combination of above 3 issues | All of the above |

---

## Additional Debugging Tips

If issues persist after applying fixes:

1. **Check channel IDs**:
```rust
// Add to auto_detect():
eprintln!("Channel {}: {} ({}) flip={}", ch.id, role, gen, flip);
```

2. **Verify heading calculations**:
```rust
// Add to segment loop in write_kmz():
eprintln!("Segment {}: heading {:.1}° (start lat {:.6} → end lat {:.6})",
    seg_idx, h_start.to_degrees(), start_ping.latitude, end_ping.latitude);
```

3. **Log corner coordinates**:
```rust
// After computing corners:
eprintln!("Corners: SW({:.6},{:.6}) SE({:.6},{:.6}) NE({:.6},{:.6}) NW({:.6},{:.6})",
    corners[0].0, corners[0].1,
    corners[1].0, corners[1].1,
    corners[2].0, corners[2].1,
    corners[3].0, corners[3].1
);
```

---

## Impact Assessment

These fixes resolve:
✅ Streaking/banding in sidescan mosaics
✅ Geometric distortion ("fractal" pattern)
✅ KML overlay misalignment
✅ Left/right channel swap on UHD units
✅ Rotation errors in ground overlays
✅ Track direction handling for KMZ exports

The fixes maintain backward compatibility with existing channel_alignment.json files
while correctly handling all three hardware generations (Classic, UHD, UHD2).
