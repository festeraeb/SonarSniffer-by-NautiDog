# Quick Start: Fixing Sonar Processing Issues

## TL;DR - Critical Fixes

Your sonar processing has **3 critical bugs**:

1. **Channel alignment**: UHD channels incorrectly flipped → left/right swap + streaking
2. **Heading calculation**: `atan2` arguments backwards → 90° rotation error
3. **Corner ordering**: Wrong geographic mapping → geometric warping

All fixes are ready to apply!

---

## Step 1: Apply Channel Alignment Fix

**File**: `channel_alignment.rs`  
**Lines**: 105-120  
**Action**: Replace with fixed code from `channel_alignment_FIXED.rs`

### The Problem:
```rust
flip: role.contains("port"),   // ❌ WRONG for UHD units
```

### The Solution:
```rust
let flip = match gen {
    "uhd2" => role.contains("port"),  // Ch 14/15: standard
    "uhd"  => false,                  // Ch 4/5: NEITHER flip! ✓
    "classic" => role.contains("port"), // Ch 0-3: standard
    _ => role.contains("port"),
};
```

**Why**: Garmin UHD (channels 4-7) pre-processes both sides to start far-range. Flipping either breaks alignment.

---

## Step 2: Fix Heading Calculation

**File**: `outputs.rs`  
**Line**: ~1492  
**Action**: Replace function body

### The Problem:
```rust
fn heading_between(a: &Ping, b: &Ping) -> f64 {
    (b.longitude - a.longitude).atan2(b.latitude - a.latitude)  // ❌ BACKWARDS
}
```

### The Solution:
```rust
fn heading_between(a: &Ping, b: &Ping) -> f64 {
    let delta_lon = b.longitude - a.longitude;
    let delta_lat = b.latitude - a.latitude;
    delta_lon.atan2(delta_lat)  // ✓ CORRECT: atan2(east, north)
}
```

**Why**: Standard geographic bearing is `atan2(Δlon, Δlat)` for north-up coords. You had it flipped.

---

## Step 3: Fix Corner Ordering

**File**: `outputs.rs`  
**Lines**: ~2275-2280  
**Action**: Replace corner assignment logic

### The Problem:
```rust
let corners = [
    (el_lon, el_lat),  // ❌ Assumes track always goes north
    (er_lon, er_lat),
    (sr_lon, sr_lat),
    (sl_lon, sl_lat),
];
```

### The Solution:
```rust
let start_is_south = start_ping.latitude <= end_ping.latitude;

let corners = if start_is_south {
    // Northbound: start=south, end=north
    [(sl_lon, sl_lat), (sr_lon, sr_lat), (er_lon, er_lat), (el_lon, el_lat)]
} else {
    // Southbound: start=north, end=south
    [(el_lon, el_lat), (er_lon, er_lat), (sr_lon, sr_lat), (sl_lon, sl_lat)]
};
```

**Why**: `gx:LatLonQuad` requires geographic order (SW,SE,NE,NW), not image row order. Must handle both directions.

---

## Step 4: Test

```bash
chmod +x test_sonar_processing.sh
./test_sonar_processing.sh your_file.rsd
```

Checks:
- ✅ Mosaic has no streaking
- ✅ Port/starboard align at nadir
- ✅ KMZ overlays follow track
- ✅ No geometric warping

---

## Step 5: Verify in Google Earth

1. Open `test_output_*/track.kmz`
2. Check:
   - Overlays follow GPS track precisely
   - No rotation/flipping artifacts
   - Structures align with satellite imagery
   - Turns don't cause "folding"

---

## Files Provided

| File | Purpose |
|------|---------|
| `SONAR_FIXES.md` | Detailed explanation of all issues |
| `channel_alignment_FIXED.rs` | Complete fixed channel_alignment.rs |
| `OUTPUTS_RS_FIXES.md` | Detailed patches for outputs.rs |
| `test_sonar_processing.sh` | Automated test suite |
| `QUICK_START.md` | This file |

---

## Expected Before/After

### Before (Broken):
- Horizontal banding in mosaics ❌
- Port/starboard swapped on UHD ❌
- KMZ overlays rotated 90° ❌
- Geometric "fractal" warping ❌
- Overlays misaligned with track ❌

### After (Fixed):
- Smooth mosaics, no banding ✅
- Correct left/right orientation ✅
- KMZ overlays aligned with track ✅
- Clean geometry, no warping ✅
- Accurate georeferencing ✅

---

## If Issues Persist

1. **Enable debug output**: Add `eprintln!()` statements per `OUTPUTS_RS_FIXES.md`
2. **Check channel IDs**: Verify your hardware matches expected (4/5 for UHD, 14/15 for UHD2)
3. **Examine logs**: Test script creates detailed logs in output directory
4. **Share debugging info**:
   - Channel detection log
   - First/last segment coordinates
   - Sample mosaic PNG
   - KMZ file

---

## Critical Points to Remember

1. **UHD is special**: Channels 4-7 NEVER flip (both pre-processed far-range)
2. **Direction matters**: Northbound vs southbound tracks need different corner ordering
3. **atan2 order**: Always `atan2(east_offset, north_offset)` for geographic bearings
4. **Test thoroughly**: Bad overlays can look "close" but be wrong by meters

---

## Summary

Three lines of code to change:
1. Channel flip logic (1 line)
2. atan2 call (1 line)  
3. Corner array (6 lines)

Impact: Fixes ALL your visible artifacts!

Ready to apply?
